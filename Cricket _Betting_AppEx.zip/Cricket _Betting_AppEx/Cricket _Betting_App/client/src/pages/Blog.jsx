import BlogPost from "../components/BlogPost"

const Blog = () => {
  return (
   <section className="fex fex_direction container ">
    <div className="p_1 m-auto flex .gap_20">
    <BlogPost />
    </div>
   
   </section>
  )
}

export default Blog