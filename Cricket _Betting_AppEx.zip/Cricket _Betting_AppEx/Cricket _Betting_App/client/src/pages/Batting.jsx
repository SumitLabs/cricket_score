import "./batting.css";
import { GoDotFill } from "react-icons/go";
// import { getMatches } from "./Api";
// import { useEffect, useState } from "react";

const Batting = () => {
  // const [matches, setMatches] = useState([]);

  // useEffect(() => {
  //   getMatches()
  //     .then((data) => {
  //       if (data && data.data) {
  //         console.log("DATA:", data.data);
  //         setMatches(data.data);
  //       } else {
  //         console.log("No data received");
  //       }
  //     })
  //     .catch((error) => console.error("API Fetch Error:", error));
  // }, []);

  return (
    <div className="container flex flex_direction">
      <div className="score_board">
        <img src="img_06.jpg" alt="" />
        <div className="overlay flex">
          <div className="team_1">
            <p>IND</p>
            <p>103/7</p>
            <p>0.3</p>
          </div>
          <div className="live_score">
            <div className="flex center live_icon">
              <GoDotFill className="live_icon" />
              <h3 className="m-x-4">Live Score</h3>
            </div>
            <div className="score">150/3</div>
            <div className="over"></div>
          </div>
          <div className="team_2">
            <p>IND</p>
            <p>99/6</p>
            <p>0.3</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Batting;
